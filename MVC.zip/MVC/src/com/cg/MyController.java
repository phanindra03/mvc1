package com.cg;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
@RequestMapping("/hello")
	public ModelAndView mvc(){
		String today=new Date().toString();
		return new ModelAndView("hello","today",today);
	}
	
@RequestMapping("/hello1")
public ModelAndView mvc2(){
	String name="vijay";
	return new ModelAndView("login");
}
	
	
	@RequestMapping(value="/showPage",method=RequestMethod.GET)
	public String mvc3(Model model){
		String name="vijay";
		model.addAttribute("name",name);
		return "success";
}


}
