package com.cg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

	@RequestMapping("/login")
	public ModelAndView mvc3(){
		String username="vijay";
		return new ModelAndView("log","success",username);
	}
	
	@RequestMapping("/servlet1")
	public String mvc4(@RequestParam("un")String n,@RequestParam("pwd")String pass,Model m)
	{
		m.addAttribute("user",n);
		return "success";
	}
	
	
}
